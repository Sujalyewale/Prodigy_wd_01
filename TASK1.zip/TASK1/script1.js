// script1.js
document.addEventListener("DOMContentLoaded", function() {
    const navbarLinks = document.querySelectorAll('.nav li a');

    navbarLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);

            window.scrollTo({
                top: targetSection.offsetTop - document.querySelector('.section-navbar').offsetHeight,
                behavior: 'smooth'
            });
        });
    });
});
